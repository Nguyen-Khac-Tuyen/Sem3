﻿using Microsoft.EntityFrameworkCore;
using ThucHanhh.Models;

namespace ThucHanhh.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> products { get; set; }
    }
}