﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThucHanhh.Models
{
    public class Product
    {
        [Key]
        public int ProductIdId { get; set; }
        public string ProductName { get; set; }
        public int SupplierlID { get; set; }
        public int CategoryID { get; set;}
        public int QuantityPerUnit { get; set; }
        public int UnitPrice { get; set;}
        public int UnisInStock { get; set; }
        public int UnisOnOrder { get; set; }
        public int ReorderLevel { get; set; }
        public string Discontinued { get; set;}
        [ForeignKey("CategoryID") ]
         public Category Category { get; set; }
    }
}
